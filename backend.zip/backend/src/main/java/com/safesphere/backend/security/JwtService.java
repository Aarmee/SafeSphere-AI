package com.safesphere.backend.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import org.springframework.stereotype.Service;

import javax.crypto.SecretKey;
import java.util.Date;

@Service
public class JwtService {

    private static final String SECRET =
            "SafeSphereAuthenticationSecretKey2026SafeSphereAuthenticationSecretKey";

    private final SecretKey key =
            Keys.hmacShaKeyFor(SECRET.getBytes());

    public String generateToken(String email){

        return Jwts.builder()

                .subject(email)

                .issuedAt(new Date())

                .expiration(
                        new Date(System.currentTimeMillis()
                                +1000*60*60*24))

                .signWith(key)

                .compact();

    }

    public String extractUsername(String token){

        Claims claims =

                Jwts.parser()

                        .verifyWith(key)

                        .build()

                        .parseSignedClaims(token)

                        .getPayload();

        return claims.getSubject();

    }

    public boolean isTokenValid(String token,String email){

        return extractUsername(token).equals(email);

    }

}